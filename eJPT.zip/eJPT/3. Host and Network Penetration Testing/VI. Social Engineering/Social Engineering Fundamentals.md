
1. Spear Phishing - Targeted Phishing
2. Whaling - Spear Phishing of high-value individuals
3. Smishing - Like phishing but through SMS messaging
4. Vishing - Like phising but through voice calls


Who would fall for social engineering

1. pharming - Redirecting web traffic maliciously
2. watering hole - use a  trusted site against you
3. bec - business email compromise
4. impersonation/spoofing - additional tactic

