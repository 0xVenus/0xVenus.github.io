
>If your IP is "10.10.10.2", then it's possible for the target IP to be "10.10.10.3"

>Also try checking the "/etc/hosts" file to take notes of the IP address there

>For ftp if anonymous login isn't allowed, try to bruteforce for username and pass

>searchsploit can be used to download  exploits manually

>Always check the php version, it might also be vulnerable. Also check the "phpinfo.php" directory

>Always check versions for services like ssh, ftp etc

>Also, try bruteforcing creds for services if there's a dead end

>For webpages checking robots.txt and xml files is a must

>The exam is more of a penetration testing activity and not a capture the flag activity. So, document all processes as  you go on with the pentest

>To paste stuffs from your clipboard to the lab environment "ctrl + shift + alt" and "ctrl + shift + v " to paste

