<h4>Cybersecurity Basics</h4>
CIA Triad(Confidentiality,Integrity,Availability)


<h4>compliance</h4>
Regulations
1. PCI DSS (payment card industry Data security standard)
2. HIPAA (Health Insurance Portability and Accountability)
3. GDPR (General Data Protection Regulation)
4. CPPA (California Consumer Privacy Act)
5. SOX (Sarbanes-Oxley Act of 2002)

>The privacy regulation that specifically applies to organizations doing business in the European Union (EU) and the European Economic Area (EEA) is the General Data Protection Regulation (GDPR)


<h4>Frameworks and Maturity</h4>
1. ISO/IEC 27000
2. COBIT
3. NIST
4. CIS
5. CMMC
6. ASD

The essential 8
1. Application Control
2. Patch Applications
3. Configure Microsoft Office Macros
4. User Application Hardening
5. Restrict Admin Privileges
6. Patch Operating System
7. Multi-factor Authentication
8. Daily Backups



<h4>Auditing</h4>

Includes, interviews, review paperwork,Assessments,Take good notes ,Mind Map,Reports

Auditing tools include
1. Nessus
2. Nmap
3. SCAP Scan and Stigviewer

